var consts = {
    hostUrl: __API__
}

module.exports = consts;