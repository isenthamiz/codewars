import React from 'react';

const UnAuthorized = () => {
    return (
        <div>
            <p>UnAuthorized Page</p>
        </div>
    )
}

export default UnAuthorized;